<?php

	ini_set('display_erros', 1);
	require_once('vistas/VistaJson.php');
	require_once('controladores/ControladorRutina.php');
	require_once('modelos/Rutina.php');

	$vista = new VistaJson();

	set_exception_handler(function ($exception) use ($vista){
		$cuerpo = array(
			array(
				"estado" => $exception->estado,
				"mensaje" => $exception->getMessage()
			)
		);
		if ($exception->getCode()){
			$vista->estado = $exception->getCode();
		}else{
			$vista->estado = 500;
		}
		$vista->imprimir($cuerpo);
	}
	);
	
	$nombre = $_REQUEST['nombre'];
	$objetivo = $_REQUEST['objetivo'];
	
	$id = $_REQUEST ['id'];
	
	// $nombre, $apellidos, $imagen, $token, $email, $contrasena, $telefono, $descripcion, $id_grupo;
	$RUTINA = new Rutina($nombre, $objetivo);
	$ControladorRutina = new ControladorRutina();
	$vista->imprimir($ControladorRutina->modificarRutina($RUTINA, $id));