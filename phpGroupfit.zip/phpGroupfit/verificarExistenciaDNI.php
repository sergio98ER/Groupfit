<?php
ini_set('display_erros', 1);
require_once('vistas/VistaJson.php');
require_once('controladores/ControladorUsuarios.php');
require_once('modelos/Usuario.php');

$vista = new VistaJson();

set_exception_handler(function ($exception) use ($vista){
	$cuerpo = array(
		array(
			"estado" => $exception->estado,
			"mensaje" => $exception->getMessage()
		)
	);
	if ($exception->getCode()){
		$vista->estado = $exception->getCode();
	}else{
		$vista->estado = 500;
	}
	$vista->imprimir($cuerpo);
}
);

$dni = $_REQUEST['dni'];

$controladoru = new ControladorUsuarios();
$vista->imprimir($controladoru->verificarExistenciaDNI($dni));