<?php

require_once('vistas/VistaJson.php');
require_once('controladores/ControladorEjercicios.php');


$vista = new VistaJson();

set_exception_handler(function ($exception) use ($vista){
	$cuerpo = array(
		array(
			"estado" => $exception->estado,
			"mensaje" => $exception->getMessage()
		)
	);
	if ($exception->getCode()){
		$vista->estado = $exception->getCode();
	}else{
		$vista->estado = 500;
	}
	$vista->imprimir($cuerpo);
}
);

// $nombre, $objetivo, $id_usuario, $id_entrenador;
$id_rutina = $_REQUEST['id_rutina'];

$ControladorEjercicios = new ControladorEjercicios();

$vista->imprimir($ControladorEjercicios->obtenerEjerciciosRutina($id_rutina));