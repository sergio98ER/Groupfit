<?php

	ini_set('display_erros', 1);
	require_once('vistas/VistaJson.php');
	require_once('controladores/ControladorEjercicios.php');
	require_once('modelos/Ejercicio.php');

	$vista = new VistaJson();

	set_exception_handler(function ($exception) use ($vista){
		$cuerpo = array(
			array(
				"estado" => $exception->estado,
				"mensaje" => $exception->getMessage()
			)
		);
		if ($exception->getCode()){
			$vista->estado = $exception->getCode();
		}else{
			$vista->estado = 500;
		}
		$vista->imprimir($cuerpo);
	}
	);
	
	$peso_inicio = $_REQUEST['peso_inicio'];
	$peso_fin = $_REQUEST['peso_fin'];
	
	$id = $_REQUEST['rutina'];
	$nombre_ejercicio = $_REQUEST['nombre_ejercicio'];
	

	
	$controladorEjercicio = new ControladorEjercicios();
	$vista->imprimir($controladorEjercicio->modificarPesosEjercicio($peso_inicio, $peso_fin, $id, $nombre_ejercicio));