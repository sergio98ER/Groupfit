<?php

require_once('vistas/VistaJson.php');
require_once('controladores/ControladorGrupos.php');
require_once('modelos/Grupo.php');

$vista = new VistaJson();

set_exception_handler(function ($exception) use ($vista){
	$cuerpo = array(
		array(
			"estado" => $exception->estado,
			"mensaje" => $exception->getMessage()
		)
	);
	if ($exception->getCode()){
		$vista->estado = $exception->getCode();
	}else{
		$vista->estado = 500;
	}
	$vista->imprimir($cuerpo);
}
);

// $nombre, $objetivo, $id_usuario, $id_entrenador;

$nombre = $_REQUEST['nombre'];
$objetivo = $_REQUEST['objetivo'];
$id_entrenador = $_REQUEST['id_entrenador'];


 
$grupo = new Grupo($nombre, $objetivo, $id_entrenador);

$controladorgrupo = new ControladorGrupos();

$vista->imprimir($controladorgrupo->insertarGrupo($grupo));