<?php

require_once('vistas/VistaJson.php');
require_once('controladores/ControladorEjercicios.php');
require_once('modelos/Ejercicio.php');

$vista = new VistaJson();

set_exception_handler(function ($exception) use ($vista){
	$cuerpo = array(
		array(
			"estado" => $exception->estado,
			"mensaje" => $exception->getMessage()
		)
	);
	if ($exception->getCode()){
		$vista->estado = $exception->getCode();
	}else{
		$vista->estado = 500;
	}
	$vista->imprimir($cuerpo);
}
);

// $nombre, $objetivo, $id_usuario, $id_entrenador;

$rutina = $_REQUEST['id_rutina'];
$musculo = $_REQUEST['musculo'];
$nombre_ejercicio = $_REQUEST['nombre_ejercicio'];
$series_ejercicio = $_REQUEST['series_ejercicio'];
$repeticiones_ejercicio = $_REQUEST['repeticiones_ejercicio'];
$peso_inicio = $_REQUEST['peso_inicio'];
$peso_fin = $_REQUEST['peso_fin'];


 
$ejercicio = new Ejercicio($rutina, $musculo, $nombre_ejercicio, $series_ejercicio, $repeticiones_ejercicio, $peso_inicio, $peso_fin);

$controladorejercicio = new ControladorEjercicios();

$vista->imprimir($controladorejercicio->insertarEjercicio($ejercicio));