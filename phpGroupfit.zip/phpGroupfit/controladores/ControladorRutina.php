<?php

require_once('datos/ConexionBD.php');
require_once('utilidades/ExcepcionApi.php');
require_once('datos/mensajes.php');

class ControladorRutina{
		
	const NOMBRE_TABLA = "rutina";
	const NOMBRE = "nombre";
	const DESCRIPCION = "descripcion";
	

	
	public function obtenerRutinaPorId($id){
		try{
			$pdo = ConexionBD::obtenerInstancia()->obtenerBD();
			
			$comando = "SELECT * FROM " . self::NOMBRE_TABLA . " where id_rutina = ?";
			$sentencia = $pdo->prepare($comando);
			$sentencia->bindValue(1, $id, PDO::PARAM_STR);
			$resultado = $sentencia->execute();
			$array = array();
			while ($row = $sentencia->fetch(PDO::FETCH_ASSOC)){
				array_push($array, $row);
			}
			return[
				[
					"estado" => 1,
					"mensaje" => $array
				]
			];
		}catch (PDOException $e){
			throw new ExcepcionApi(1, $e->getMessage());
		}
		switch ($resultado) 
        {
            case 0:
                http_response_code(200);
                break;
            case 1:
                throw new ExcepcionApi(1, "Ha ocurrido un error.");
                break;
            default:
                throw new ExcepcionApi(ESTADO_FALLA_DESCONOCIDA, "Fallo desconocido.", 400);
        }
	}
	public function modificarRutina($RUTINA, $id){
		try{
			$pdo = ConexionBD::obtenerInstancia()->obtenerBD();
			//nombre, apellidos, token, email, telefono, contrasena, descripcion;
			$comando = "UPDATE " . self::NOMBRE_TABLA . " SET " . self:: NOMBRE . " = ? , " . self::DESCRIPCION . " = ? WHERE id_rutina = ?";
			$sentencia = $pdo->prepare($comando);
			$sentencia->bindValue(1, $RUTINA->getNombre(), PDO::PARAM_STR);
			$sentencia->bindValue(2, $RUTINA->getDescripcion(), PDO::PARAM_STR);
			$sentencia->bindValue(3, $id, PDO::PARAM_STR);
			
			$resultado = $sentencia->execute();
			$array = array();
		while ($row = $sentencia->fetch(PDO::FETCH_ASSOC)){
			array_push($array, $row);
		}
		return[
			[
				"estado" => 1,
				"mensaje" => $array
			]
		];
	}catch (PDOException $e){
		throw new ExcepcionApi(1, $e->getMessage());
	}
	switch ($resultado){
            case 0:
                http_response_code(200);
                break;
            case 1:
                throw new ExcepcionApi(1, "Ha ocurrido un error.");
                break;
            default:
                throw new ExcepcionApi(ESTADO_FALLA_DESCONOCIDA, "Fallo desconocido.", 400);
        }
	}
	
	public function insertarRutina($rutina){
		try{
			$pdo = ConexionBD::obtenerInstancia()->obtenerBD();
			$comando = "INSERT INTO " . self::NOMBRE_TABLA . " ( " . self::NOMBRE. "," . self::DESCRIPCION . ")" . " VALUES(?,?)";
			$sentencia = $pdo->prepare($comando);
			$sentencia->bindValue(1, $rutina->getNombre(), PDO::PARAM_STR);
			$sentencia->bindValue(2, $rutina->getDescripcion(), PDO::PARAM_STR);
			
		
			$resultado = $sentencia->execute();
		}catch (PDOException $e){
			throw new ExcepcionApi(1, $e->getMessage());
		}
		switch ($resultado) 
        {
            case 0:
                http_response_code(200);
                break;
            case 1:
                throw new ExcepcionApi(1, "Ha ocurrido un error.");
                break;
            default:
                throw new ExcepcionApi(ESTADO_FALLA_DESCONOCIDA, "Fallo desconocido.", 400);
        }
	}
	public function comprobarNombreRutina($nombre){
		try{
			$pdo = ConexionBD::obtenerInstancia()->obtenerBD();

			$comando = "SELECT * FROM ". self::NOMBRE_TABLA . " WHERE " . self::NOMBRE . " = ? ";
			$sentencia = $pdo->prepare($comando);
			$sentencia->bindValue(1, $nombre, PDO::PARAM_STR);
			$resultado = $sentencia->execute();
		$array = array();
		while ($row = $sentencia->fetch(PDO::FETCH_ASSOC)){
			array_push($array, $row);
		}
		return[
			[
				"estado" => 1,
				"mensaje" => $array
			]
		];
	}catch (PDOException $e){
		throw new ExcepcionApi(ESTADO_ERROR_BD, $e->getMessage());
	}
	switch ($resultado) 
        {
            case 0:
                http_response_code(200);
                break;
            case 1:
                throw new ExcepcionApi(1, "Ha ocurrido un error.");
                break;
            default:
                throw new ExcepcionApi(ESTADO_FALLA_DESCONOCIDA, "Fallo desconocido.", 400);
        }
	}
	public function obtenerRutinas(){
		try{
			$pdo = ConexionBD::obtenerInstancia()->obtenerBD();

			$comando = "SELECT * FROM ". self::NOMBRE_TABLA ;
			
			$sentencia = $pdo->prepare($comando);
			$resultado = $sentencia->execute();
			
		$array = array();
		while ($row = $sentencia->fetch(PDO::FETCH_ASSOC)){
			array_push($array, $row);
		}
		return[
			[
				"estado" => 1,
				"mensaje" => $array
			]
		];
	}catch (PDOException $e){
		throw new ExcepcionApi(ESTADO_ERROR_BD, $e->getMessage());
	}
	switch ($resultado) 
        {
            case 0:
                http_response_code(200);
                break;
            case 1:
                throw new ExcepcionApi(1, "Ha ocurrido un error.");
                break;
            default:
                throw new ExcepcionApi(ESTADO_FALLA_DESCONOCIDA, "Fallo desconocido.", 400);
        }
	}
	
	
	
		public function borrarRutina($nombre){
		try{
			$pdo = ConexionBD::obtenerInstancia()->obtenerBD();
			
			$comando = "DELETE FROM " . self::NOMBRE_TABLA . " where " . self::NOMBRE . " = ?";
			$sentencia = $pdo->prepare($comando);
			$sentencia->bindValue(1, $nombre, PDO::PARAM_STR);
			$resultado = $sentencia->execute();
			$array = array();
		while ($row = $sentencia->fetch(PDO::FETCH_ASSOC)){
			array_push($array, $row);
		}
		return[
			[
				"estado" => 1,
				"mensaje" => $array
			]
		];
		}catch (PDOException $e){
			throw new ExcepcionApi(1, $e->getMessage());
		}
		switch ($resultado) 
        {
            case 0:
                http_response_code(200);
                break;
            case 1:
                throw new ExcepcionApi(1, "Ha ocurrido un error.");
                break;
            default:
                throw new ExcepcionApi(ESTADO_FALLA_DESCONOCIDA, "Fallo desconocido.", 400);
        }
	}
	
	
	public function obtenerIdRutina($nombre){
		try{
			$pdo = ConexionBD::obtenerInstancia()->obtenerBD();
			
			$comando = "SELECT id_rutina FROM " . self::NOMBRE_TABLA . " where " . self::NOMBRE . " = ?";
			$sentencia = $pdo->prepare($comando);
			$sentencia->bindValue(1, $nombre, PDO::PARAM_STR);
			$resultado = $sentencia->execute();
			$array = array();
			while ($row = $sentencia->fetch(PDO::FETCH_ASSOC)){
				array_push($array, $row);
			}
			return[
				[
					"estado" => 1,
					"mensaje" => $array
				]
			];
		}catch (PDOException $e){
			throw new ExcepcionApi(1, $e->getMessage());
		}
		switch ($resultado) 
        {
            case 0:
                http_response_code(200);
                break;
            case 1:
                throw new ExcepcionApi(1, "Ha ocurrido un error.");
                break;
            default:
                throw new ExcepcionApi(ESTADO_FALLA_DESCONOCIDA, "Fallo desconocido.", 400);
        }
	}
	
	public function obtenerNombreRutinaPorID($id){
		try{
			$pdo = ConexionBD::obtenerInstancia()->obtenerBD();
			
			$comando = "SELECT ". self::NOMBRE . " FROM " . self::NOMBRE_TABLA . " where id_rutina = ?";
			$sentencia = $pdo->prepare($comando);
			$sentencia->bindValue(1, $id, PDO::PARAM_STR);
			$resultado = $sentencia->execute();
			$array = array();
			while ($row = $sentencia->fetch(PDO::FETCH_ASSOC)){
				array_push($array, $row);
			}
			return[
				[
					"estado" => 1,
					"mensaje" => $array
				]
			];
		}catch (PDOException $e){
			throw new ExcepcionApi(1, $e->getMessage());
		}
		switch ($resultado) 
        {
            case 0:
                http_response_code(200);
                break;
            case 1:
                throw new ExcepcionApi(1, "Ha ocurrido un error.");
                break;
            default:
                throw new ExcepcionApi(ESTADO_FALLA_DESCONOCIDA, "Fallo desconocido.", 400);
        }
	}
	
	public function obtenerNombresRutinasPorIdMenosElDelUsuario($id){
		try{
			$pdo = ConexionBD::obtenerInstancia()->obtenerBD();
			
			$comando = "SELECT ". self::NOMBRE . " FROM " . self::NOMBRE_TABLA . " where id_rutina != ?";
			$sentencia = $pdo->prepare($comando);
			$sentencia->bindValue(1, $id, PDO::PARAM_STR);
			$resultado = $sentencia->execute();
			$array = array();
			while ($row = $sentencia->fetch(PDO::FETCH_ASSOC)){
				array_push($array, $row);
			}
			return[
				[
					"estado" => 1,
					"mensaje" => $array
				]
			];
		}catch (PDOException $e){
			throw new ExcepcionApi(1, $e->getMessage());
		}
		switch ($resultado) 
        {
            case 0:
                http_response_code(200);
                break;
            case 1:
                throw new ExcepcionApi(1, "Ha ocurrido un error.");
                break;
            default:
                throw new ExcepcionApi(ESTADO_FALLA_DESCONOCIDA, "Fallo desconocido.", 400);
        }
	}
	}
		
		
	
	

/*public function obtenerTodosUsuariosMRegis($usuario){
		try{
		$pdo = ConexionBD::obtenerInstancia()->obtenerBD();
		$comando = "Select ". self::NOMBRE . " from " . self::NOMBRE_TABLA . " where " . self::NOMBRE . " != ?";
		$sentencia = $pdo->prepare($comando);
		$sentencia->bindValue(1, $usuario->getUsuario(), PDO::PARAM_STR);
		$resultado = $sentencia->execute();
		$array = array();
		while ($row = $sentencia->fetch(PDO::FETCH_ASSOC)){
			array_push($array, $row);
		}
		return[
			[
				"estado" => 1,
				"mensaje" => $array
			]
		];
	}catch (PDOException $e){
		throw new ExcepcionApi(ESTADO_ERROR_BD, $e->getMessage());
	}
	switch ($resultado) 
        {
            case 0:
                http_response_code(200);
                break;
            case 1:
                throw new ExcepcionApi(1, "Ha ocurrido un error.");
                break;
            default:
                throw new ExcepcionApi(ESTADO_FALLA_DESCONOCIDA, "Fallo desconocido.", 400);
        }
	}*/