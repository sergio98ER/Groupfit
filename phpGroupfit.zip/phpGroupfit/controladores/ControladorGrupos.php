<?php

require_once('datos/ConexionBD.php');
require_once('utilidades/ExcepcionApi.php');
require_once('datos/mensajes.php');

class ControladorGrupos{
		// $nombre, $objetivo, $id_usuario, $id_entrenador;
	const NOMBRE_TABLA = "grupo";
	const NOMBRE = "nombre";
	const OBJETIVO = "objetivo";
	const ID_ENTRENADOR = "id_entrenador";
	
	public function insertarGrupo($grupo){
		try{
			$pdo = ConexionBD::obtenerInstancia()->obtenerBD();
			$comando = "INSERT INTO " . self::NOMBRE_TABLA . " ( " . self::NOMBRE. "," . self::OBJETIVO . "," . self::ID_ENTRENADOR . ")" . " VALUES(?,?,?)";
			$sentencia = $pdo->prepare($comando);
			$sentencia->bindValue(1, $grupo->getNombre(), PDO::PARAM_STR);
			$sentencia->bindValue(2, $grupo->getObjetivo(), PDO::PARAM_STR);
			$sentencia->bindValue(3, $grupo->getId_entrenador(), PDO::PARAM_STR);
		
			$resultado = $sentencia->execute();
		}catch (PDOException $e){
			throw new ExcepcionApi(1, $e->getMessage());
		}
		switch ($resultado) 
        {
            case 0:
                http_response_code(200);
                break;
            case 1:
                throw new ExcepcionApi(1, "Ha ocurrido un error.");
                break;
            default:
                throw new ExcepcionApi(ESTADO_FALLA_DESCONOCIDA, "Fallo desconocido.", 400);
        }
	}
	public function obtenerGrupos(){
		try{
			$pdo = ConexionBD::obtenerInstancia()->obtenerBD();

			$comando = "SELECT * FROM ". self::NOMBRE_TABLA ;
			
			$sentencia = $pdo->prepare($comando);
			$resultado = $sentencia->execute();
			
		$array = array();
		while ($row = $sentencia->fetch(PDO::FETCH_ASSOC)){
			array_push($array, $row);
		}
		return[
			[
				"estado" => 1,
				"mensaje" => $array
			]
		];
	}catch (PDOException $e){
		throw new ExcepcionApi(ESTADO_ERROR_BD, $e->getMessage());
	}
	switch ($resultado) 
        {
            case 0:
                http_response_code(200);
                break;
            case 1:
                throw new ExcepcionApi(1, "Ha ocurrido un error.");
                break;
            default:
                throw new ExcepcionApi(ESTADO_FALLA_DESCONOCIDA, "Fallo desconocido.", 400);
        }
	}
	public function modificarGrupo($grupo, $id){
		try{
			$pdo = ConexionBD::obtenerInstancia()->obtenerBD();
			//nombre, apellidos, token, email, telefono, contrasena, descripcion;
			$comando = "UPDATE " . self::NOMBRE_TABLA . " SET " . self:: NOMBRE . " = ? , " . self::OBJETIVO . " = ? , " . self::ID_ENTRENADOR . " = 1 WHERE id = ?";
			$sentencia = $pdo->prepare($comando);
			$sentencia->bindValue(1, $grupo->getNombre(), PDO::PARAM_STR);
			$sentencia->bindValue(2, $grupo->getObjetivo(), PDO::PARAM_STR);
			$sentencia->bindValue(3, $id, PDO::PARAM_STR);
			
			$resultado = $sentencia->execute();
			$array = array();
		while ($row = $sentencia->fetch(PDO::FETCH_ASSOC)){
			array_push($array, $row);
		}
		return[
			[
				"estado" => 1,
				"mensaje" => $array
			]
		];
	}catch (PDOException $e){
		throw new ExcepcionApi(1, $e->getMessage());
	}
	switch ($resultado){
            case 0:
                http_response_code(200);
                break;
            case 1:
                throw new ExcepcionApi(1, "Ha ocurrido un error.");
                break;
            default:
                throw new ExcepcionApi(ESTADO_FALLA_DESCONOCIDA, "Fallo desconocido.", 400);
        }
	}
	
		public function borrarGrupo($nombre){
		try{
			$pdo = ConexionBD::obtenerInstancia()->obtenerBD();
			
			$comando = "DELETE FROM " . self::NOMBRE_TABLA . " where " . self::NOMBRE . " = ?";
			$sentencia = $pdo->prepare($comando);
			$sentencia->bindValue(1, $nombre, PDO::PARAM_STR);
			$resultado = $sentencia->execute();
			$array = array();
		while ($row = $sentencia->fetch(PDO::FETCH_ASSOC)){
			array_push($array, $row);
		}
		return[
			[
				"estado" => 1,
				"mensaje" => $array
			]
		];
		}catch (PDOException $e){
			throw new ExcepcionApi(1, $e->getMessage());
		}
		switch ($resultado) 
        {
            case 0:
                http_response_code(200);
                break;
            case 1:
                throw new ExcepcionApi(1, "Ha ocurrido un error.");
                break;
            default:
                throw new ExcepcionApi(ESTADO_FALLA_DESCONOCIDA, "Fallo desconocido.", 400);
        }
	}
	
		public function obtenerGrupoNombre($nombre){
		try{
			$pdo = ConexionBD::obtenerInstancia()->obtenerBD();
			
			$comando = "SELECT * FROM " . self::NOMBRE_TABLA . " where " . self::NOMBRE . " = ?";
			$sentencia = $pdo->prepare($comando);
			$sentencia->bindValue(1, $nombre, PDO::PARAM_STR);
			$resultado = $sentencia->execute();
			$array = array();
			while ($row = $sentencia->fetch(PDO::FETCH_ASSOC)){
				array_push($array, $row);
			}
			return[
				[
					"estado" => 1,
					"mensaje" => $array
				]
			];
		}catch (PDOException $e){
			throw new ExcepcionApi(1, $e->getMessage());
		}
		switch ($resultado) 
        {
            case 0:
                http_response_code(200);
                break;
            case 1:
                throw new ExcepcionApi(1, "Ha ocurrido un error.");
                break;
            default:
                throw new ExcepcionApi(ESTADO_FALLA_DESCONOCIDA, "Fallo desconocido.", 400);
        }
	}
	
	public function obtenerIdGrupo($nombre){
		try{
			$pdo = ConexionBD::obtenerInstancia()->obtenerBD();
			
			$comando = "SELECT id FROM " . self::NOMBRE_TABLA . " where " . self::NOMBRE . " = ?";
			$sentencia = $pdo->prepare($comando);
			$sentencia->bindValue(1, $nombre, PDO::PARAM_STR);
			$resultado = $sentencia->execute();
			$array = array();
			while ($row = $sentencia->fetch(PDO::FETCH_ASSOC)){
				array_push($array, $row);
			}
			return[
				[
					"estado" => 1,
					"mensaje" => $array
				]
			];
		}catch (PDOException $e){
			throw new ExcepcionApi(1, $e->getMessage());
		}
		switch ($resultado) 
        {
            case 0:
                http_response_code(200);
                break;
            case 1:
                throw new ExcepcionApi(1, "Ha ocurrido un error.");
                break;
            default:
                throw new ExcepcionApi(ESTADO_FALLA_DESCONOCIDA, "Fallo desconocido.", 400);
        }
	}
	
	public function obtenerNombreGrupoPorId($id_metido){
		try{
			$pdo = ConexionBD::obtenerInstancia()->obtenerBD();
			
			$comando = "SELECT nombre FROM " . self::NOMBRE_TABLA . " where id = ?";
			$sentencia = $pdo->prepare($comando);
			$sentencia->bindValue(1, $id_metido, PDO::PARAM_STR);
			$resultado = $sentencia->execute();
			$array = array();
			while ($row = $sentencia->fetch(PDO::FETCH_ASSOC)){
				array_push($array, $row);
			}
			return[
				[
					"estado" => 1,
					"mensaje" => $array
				]
			];
		}catch (PDOException $e){
			throw new ExcepcionApi(1, $e->getMessage());
		}
		switch ($resultado) 
        {
            case 0:
                http_response_code(200);
                break;
            case 1:
                throw new ExcepcionApi(1, "Ha ocurrido un error.");
                break;
            default:
                throw new ExcepcionApi(ESTADO_FALLA_DESCONOCIDA, "Fallo desconocido.", 400);
        }
	}
	
	public function obtenerNombreGruposMenosElDelUsuario($id_metido){
		try{
			$pdo = ConexionBD::obtenerInstancia()->obtenerBD();
			
			$comando = "SELECT nombre FROM " . self::NOMBRE_TABLA . " where id != ?";
			$sentencia = $pdo->prepare($comando);
			$sentencia->bindValue(1, $id_metido, PDO::PARAM_STR);
			$resultado = $sentencia->execute();
			$array = array();
			while ($row = $sentencia->fetch(PDO::FETCH_ASSOC)){
				array_push($array, $row);
			}
			return[
				[
					"estado" => 1,
					"mensaje" => $array
				]
			];
		}catch (PDOException $e){
			throw new ExcepcionApi(1, $e->getMessage());
		}
		switch ($resultado) 
        {
            case 0:
                http_response_code(200);
                break;
            case 1:
                throw new ExcepcionApi(1, "Ha ocurrido un error.");
                break;
            default:
                throw new ExcepcionApi(ESTADO_FALLA_DESCONOCIDA, "Fallo desconocido.", 400);
        }
	}
	}
		
		
	
	

/*public function obtenerTodosUsuariosMRegis($usuario){
		try{
		$pdo = ConexionBD::obtenerInstancia()->obtenerBD();
		$comando = "Select ". self::NOMBRE . " from " . self::NOMBRE_TABLA . " where " . self::NOMBRE . " != ?";
		$sentencia = $pdo->prepare($comando);
		$sentencia->bindValue(1, $usuario->getUsuario(), PDO::PARAM_STR);
		$resultado = $sentencia->execute();
		$array = array();
		while ($row = $sentencia->fetch(PDO::FETCH_ASSOC)){
			array_push($array, $row);
		}
		return[
			[
				"estado" => 1,
				"mensaje" => $array
			]
		];
	}catch (PDOException $e){
		throw new ExcepcionApi(ESTADO_ERROR_BD, $e->getMessage());
	}
	switch ($resultado) 
        {
            case 0:
                http_response_code(200);
                break;
            case 1:
                throw new ExcepcionApi(1, "Ha ocurrido un error.");
                break;
            default:
                throw new ExcepcionApi(ESTADO_FALLA_DESCONOCIDA, "Fallo desconocido.", 400);
        }
	}*/