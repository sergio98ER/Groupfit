<?php

	require_once('datos/ConexionBD.php');
	require_once('utilidades/ExcepcionApi.php');
	require_once('datos/mensajes.php');
	
	class ControladorMensajes{
		
		const NOMBRE_TABLA = "entrenador";
		const ID = "id";
		const TOKEN = "token";
		
	public function enviarMensajeUsuario($emisor, $mensaje){
		try{
			$pdo = ConexionBD::obtenerInstancia()->obtenerBD();
			$comando = "SELECT " . self::TOKEN . " from " . self::NOMBRE_TABLA . " where " . self::ID . " = 1";
			$sentencia = $pdo->prepare($comando);
			$sentencia->execute();
			$array = array();
			while ($row = $sentencia->fetch(PDO::FETCH_ASSOC)){
				array_push($array, $row);
			}
			}catch (PDOException $e){
				throw new ExcepcionApi(ESTADO_ERROR_BD, $e->getMessage());
			}
			$destinatarios=($array[0]['token']);
			$mensajenuevo = array ('time_to_live' => 108,
			'body' => $mensaje->getMensaje(),
			'title' => $mensaje->getTitulo(),
			'vibrate' => 1,
			'icon' => 'myicon',	// Icono por defecto
			'sound' => 'mySound' // Sonido por defecto
			);
			$datosmensaje = array (
			// Enviamos un dato extra que se llama dato1 y que vale 1
			'dato1' => 1,
			// Enviamos otro dato extra que se llama mensajeextra y que vale Hola
			'mensajeextra' => 'Hola'
			);
			$mensajefinal = array (
			// En el campo to indicamos a quién le queremos enviar el mensaje
			// En el caso de poner el token de otro dispositivo lo enviará a ese dispositivo
			'to' => $destinatarios,
			// En caso de querer enviar el mensaje a un topic (canal) habrá que poner /topics/nombrecanal
			// y lo enviará a todos los usuarios que estén subscritos a ese canal
			// 'to' => '/topics/nombrecanal',
			'notification' => $mensajenuevo,
			'data' => $datosmensaje
			);
			$cabecera = array('Authorization: key=' .API_ACCESS_KEY, 'Content-Type: application/json');
			$ch = curl_init();
			curl_setopt($ch, CURLOPT_URL, 'https://fcm.googleapis.com/fcm/send');
			curl_setopt($ch, CURLOPT_POST, true);
			curl_setopt($ch, CURLOPT_HTTPHEADER, $cabecera);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
			curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($mensajefinal));
			$resultado_mensaje = curl_exec($ch);
			curl_close($ch);
			return[
					[
						"estado" => 1,
						"mensaje" => $resultado_mensaje
					]
				];
		}
		
		public function EnviarMensajeEntrenador($emisor, $receptor, $mensaje){
		try{
			$pdo = ConexionBD::obtenerInstancia()->obtenerBD();
			$comando = "SELECT " . self::TOKEN . " from usuario where " . self::ID . " = ?";
			$sentencia = $pdo->prepare($comando);
			$sentencia->bindParam(1, $receptor);
			$sentencia->execute();
			$array = array();
			while ($row = $sentencia->fetch(PDO::FETCH_ASSOC)){
				array_push($array, $row);
			}
			}catch (PDOException $e){
				throw new ExcepcionApi(ESTADO_ERROR_BD, $e->getMessage());
			}
			$destinatarios=($array[0]['token']);
			$mensajenuevo = array ('time_to_live' => 108,
			'body' => $mensaje->getMensaje(),
			'title' => $mensaje->getTitulo(),
			'vibrate' => 1,
			'icon' => 'myicon',	// Icono por defecto
			'sound' => 'mySound' // Sonido por defecto
			);
			$datosmensaje = array (
			// Enviamos un dato extra que se llama dato1 y que vale 1
			'dato1' => 1,
			// Enviamos otro dato extra que se llama mensajeextra y que vale Hola
			'mensajeextra' => 'Hola'
			);
			$mensajefinal = array (
			// En el campo to indicamos a quién le queremos enviar el mensaje
			// En el caso de poner el token de otro dispositivo lo enviará a ese dispositivo
			'to' => $destinatarios,
			// En caso de querer enviar el mensaje a un topic (canal) habrá que poner /topics/nombrecanal
			// y lo enviará a todos los usuarios que estén subscritos a ese canal
			// 'to' => '/topics/nombrecanal',
			'notification' => $mensajenuevo,
			'data' => $datosmensaje
			);
			$cabecera = array('Authorization: key=' .API_ACCESS_KEY, 'Content-Type: application/json');
			$ch = curl_init();
			curl_setopt($ch, CURLOPT_URL, 'https://fcm.googleapis.com/fcm/send');
			curl_setopt($ch, CURLOPT_POST, true);
			curl_setopt($ch, CURLOPT_HTTPHEADER, $cabecera);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
			curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($mensajefinal));
			$resultado_mensaje = curl_exec($ch);
			curl_close($ch);
			return[
					[
						"estado" => 1,
						"mensaje" => $resultado_mensaje
					]
				];
		}
	}