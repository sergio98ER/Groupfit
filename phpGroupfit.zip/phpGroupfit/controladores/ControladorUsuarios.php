<?php

require_once('datos/ConexionBD.php');
require_once('utilidades/ExcepcionApi.php');
require_once('datos/mensajes.php');

class ControladorUsuarios{
		// $nombre, $apellidos, $email, $contrasena, $dni, $peso, $altura, $pressBanca, $dominadas, $forma_actual, $token, $tiempo_1km $id_grupo, $imagen, $id_entreno;
	const NOMBRE_TABLA = "usuario";
	const NOMBRE = "nombre";
	const APELLIDOS = "apellidos";
	const EMAIL = "email";
	const CONTRASENA = "contrasena";
	const DNI = "dni";
	const PESO = "peso";
	const ALTURA = "altura";
	const PRESSBANCA = "pressBanca";
	const DOMINADAS = "dominadas";
	const FORMA_ACTUAL = "forma_actual";
	const TOKEN = "token";
	const TIEMPO_1KM = "tiempo_1km";
	const ID_GRUPO = "id_grupo";
	const IMAGEN = "imagen";
	const ID_ENTRENO = "id_entreno";
	
	public function modificarTokenUsuario($email_usuario, $token_usuario){
		try{
			$pdo = ConexionBD::obtenerInstancia()->obtenerBD();
			//$comando = "UPDATE ". self::NOMBRE_TABLA . " SET " . self::NOMBRE . " = ? ," . self::APELLIDOS . " = ? ,". self::TOKEN . "= ?,". self::EMAIL . " = ? ,". self::TELEFONO . " = ? ," . self::CONTRASENA . " = ?,". self::DESCRIPCION . " = ?  WHERE ". self::ID . " = 1";

			$comando = "UPDATE ". self::NOMBRE_TABLA . " SET " . self::TOKEN . " = ?  WHERE " . self::EMAIL . " = ? ";
			
			$sentencia = $pdo->prepare($comando);
			$sentencia->bindValue(1, $token_usuario, PDO::PARAM_STR);
			$sentencia->bindValue(2, $email_usuario, PDO::PARAM_STR);
			$resultado = $sentencia->execute();
		$array = array();
		while ($row = $sentencia->fetch(PDO::FETCH_ASSOC)){
			array_push($array, $row);
		}
		return[
			[
				"estado" => 1,
				"mensaje" => $array
			]
		];
	}catch (PDOException $e){
		
	}
	switch ($resultado) 
        {
            case 0:
                http_response_code(200);
                break;
            case 1:
                throw new ExcepcionApi(1, "Ha ocurrido un error.");
                break;
            default:
                throw new ExcepcionApi(ESTADO_FALLA_DESCONOCIDA, "Fallo desconocido.", 400);
        }
	}
	
	public function obtenerUsuario($correo, $contrasena){
		try{
			$pdo = ConexionBD::obtenerInstancia()->obtenerBD();

			$comando = "SELECT * FROM ". self::NOMBRE_TABLA . " WHERE " . self::EMAIL . " = ? and " . self::CONTRASENA . " = ?";
			$sentencia = $pdo->prepare($comando);
			$sentencia->bindValue(1, $correo, PDO::PARAM_STR);
			$sentencia->bindValue(2, $contrasena, PDO::PARAM_STR);
			$resultado = $sentencia->execute();
		$array = array();
		while ($row = $sentencia->fetch(PDO::FETCH_ASSOC)){
			array_push($array, $row);
		}
		return[
			[
				"estado" => 1,
				"mensaje" => $array
			]
		];
	}catch (PDOException $e){
		throw new ExcepcionApi(ESTADO_ERROR_BD, $e->getMessage());
	}
	switch ($resultado) 
        {
            case 0:
                http_response_code(200);
                break;
            case 1:
                throw new ExcepcionApi(1, "Ha ocurrido un error.");
                break;
            default:
                throw new ExcepcionApi(ESTADO_FALLA_DESCONOCIDA, "Fallo desconocido.", 400);
        }
	}
	public function insertarUsuario($usuario){
		try{
			$pdo = ConexionBD::obtenerInstancia()->obtenerBD();
											// $nombre, $apellidos, $email, $contrasena, $dni, $peso, $altura, $pressBanca, $dominadas, $forma_actual, $token, $tiempo_1km $id_grupo, $imagen, $id_entreno;
			$comando = "INSERT INTO " . self::NOMBRE_TABLA . " (nombre, apellidos, email, contrasena, dni, peso, altura, pressBanca, dominadas, forma_actual, token, tiempo_1km, id_grupo, imagen, id_entreno) values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
			$sentencia = $pdo->prepare($comando);
			$sentencia->bindValue(1, $usuario->getNombre(), PDO::PARAM_STR);
			$sentencia->bindValue(2, $usuario->getApellidos(), PDO::PARAM_STR);
			$sentencia->bindValue(3, $usuario->getEmail(), PDO::PARAM_STR);
			$sentencia->bindValue(4, $usuario->getContrasena(), PDO::PARAM_STR);
			$sentencia->bindValue(5, $usuario->getDni(), PDO::PARAM_STR);
			$sentencia->bindValue(6, $usuario->getPeso(), PDO::PARAM_STR);
			$sentencia->bindValue(7, $usuario->getAltura(), PDO::PARAM_STR);
			$sentencia->bindValue(8, $usuario->getPressBanca(), PDO::PARAM_STR);
			$sentencia->bindValue(9, $usuario->getDominadas(), PDO::PARAM_STR);
			$sentencia->bindValue(10, $usuario->getForma_actual(), PDO::PARAM_STR);
			$sentencia->bindValue(11, $usuario->getToken(), PDO::PARAM_STR);
			$sentencia->bindValue(12, $usuario->getTiempo_1km(), PDO::PARAM_STR);
			$sentencia->bindValue(13, $usuario->getId_grupo(), PDO::PARAM_STR);
			$sentencia->bindValue(14, $usuario->getImagen(), PDO::PARAM_STR);
			$sentencia->bindValue(15, $usuario->getId_entreno(), PDO::PARAM_STR);
			
			$resultado = $sentencia->execute();
			$array = array();
		while ($row = $sentencia->fetch(PDO::FETCH_ASSOC)){
			array_push($array, $row);
		}
		return[
			[
				"estado" => 1,
				"mensaje" => $array
			]
		];
	}catch (PDOException $e){
		throw new ExcepcionApi(1, $e->getMessage());
	}
	switch ($resultado){
            case 0:
                http_response_code(200);
                break;
            case 1:
                throw new ExcepcionApi(1, "Ha ocurrido un error.");
                break;
            default:
                throw new ExcepcionApi(ESTADO_FALLA_DESCONOCIDA, "Fallo desconocido.", 400);
        }
	}
	public function modificarIdUsuariosEntrenoEliminado($id_entreno_eliminado, $id_entreno){
		try{
			$pdo = ConexionBD::obtenerInstancia()->obtenerBD();
											// $nombre, $apellidos, $email, $contrasena, $dni, $peso, $altura, $pressBanca, $dominadas, $forma_actual, $token, $tiempo_1km $id_grupo, $imagen, $id_entreno;
			$comando = "UPDATE " . self::NOMBRE_TABLA . " SET id_entreno = ?  WHERE id_entreno = ?";
			$sentencia = $pdo->prepare($comando);
			$sentencia->bindValue(1, $id_entreno_eliminado, PDO::PARAM_STR);
			$sentencia->bindValue(2, $id_entreno, PDO::PARAM_STR);
			
			
			$resultado = $sentencia->execute();
			$array = array();
		while ($row = $sentencia->fetch(PDO::FETCH_ASSOC)){
			array_push($array, $row);
		}
		return[
			[
				"estado" => 1,
				"mensaje" => $array
			]
		];
	}catch (PDOException $e){
		throw new ExcepcionApi(1, $e->getMessage());
	}
	switch ($resultado){
            case 0:
                http_response_code(200);
                break;
            case 1:
                throw new ExcepcionApi(1, "Ha ocurrido un error.");
                break;
            default:
                throw new ExcepcionApi(ESTADO_FALLA_DESCONOCIDA, "Fallo desconocido.", 400);
        }
	}
	public function modificarUsuario($usuario, $idusuario){
		try{
			$pdo = ConexionBD::obtenerInstancia()->obtenerBD();
											// $nombre, $apellidos, $email, $contrasena, $dni, $peso, $altura, $pressBanca, $dominadas, $forma_actual, $token, $tiempo_1km $id_grupo, $imagen, $id_entreno;
			$comando = "UPDATE " . self::NOMBRE_TABLA . " SET " . self:: NOMBRE . " = ? , " . self::APELLIDOS . " = ? , " . self::EMAIL . " = ? ," . self::CONTRASENA . " = ? ," . self::DNI . " = ? , " . self::PESO . " = ? , " . self::ALTURA . " = ? , " . self::PRESSBANCA . " = ? , " . self::DOMINADAS . " = ? , " . self::FORMA_ACTUAL . " = ? , " . self::TOKEN . " = ? , " . self::TIEMPO_1KM . " = ? , " . self::ID_GRUPO . " = ? , " . self::IMAGEN . " = ? , " . self::ID_ENTRENO . " = ? WHERE id = ?";
			$sentencia = $pdo->prepare($comando);
			$sentencia->bindValue(1, $usuario->getNombre(), PDO::PARAM_STR);
			$sentencia->bindValue(2, $usuario->getApellidos(), PDO::PARAM_STR);
			$sentencia->bindValue(3, $usuario->getEmail(), PDO::PARAM_STR);
			$sentencia->bindValue(4, $usuario->getContrasena(), PDO::PARAM_STR);
			$sentencia->bindValue(5, $usuario->getDni(), PDO::PARAM_STR);
			$sentencia->bindValue(6, $usuario->getPeso(), PDO::PARAM_STR);
			$sentencia->bindValue(7, $usuario->getAltura(), PDO::PARAM_STR);
			$sentencia->bindValue(8, $usuario->getPressBanca(), PDO::PARAM_STR);
			$sentencia->bindValue(9, $usuario->getDominadas(), PDO::PARAM_STR);
			$sentencia->bindValue(10, $usuario->getForma_actual(), PDO::PARAM_STR);
			$sentencia->bindValue(11, $usuario->getToken(), PDO::PARAM_STR);
			$sentencia->bindValue(12, $usuario->getTiempo_1km(), PDO::PARAM_STR);
			$sentencia->bindValue(13, $usuario->getId_grupo(), PDO::PARAM_STR);
			$sentencia->bindValue(14, $usuario->getImagen(), PDO::PARAM_STR);
			$sentencia->bindValue(15, $usuario->getId_entreno(), PDO::PARAM_STR);
			$sentencia->bindValue(16, $idusuario, PDO::PARAM_STR);
			
			$resultado = $sentencia->execute();
			$array = array();
		while ($row = $sentencia->fetch(PDO::FETCH_ASSOC)){
			array_push($array, $row);
		}
		return[
			[
				"estado" => 1,
				"mensaje" => $array
			]
		];
	}catch (PDOException $e){
		throw new ExcepcionApi(1, $e->getMessage());
	}
	switch ($resultado){
            case 0:
                http_response_code(200);
                break;
            case 1:
                throw new ExcepcionApi(1, "Ha ocurrido un error.");
                break;
            default:
                throw new ExcepcionApi(ESTADO_FALLA_DESCONOCIDA, "Fallo desconocido.", 400);
        }
	}
	public function borrarUsuario($email){
		try{
			$pdo = ConexionBD::obtenerInstancia()->obtenerBD();
			
			$comando = "DELETE FROM " . self::NOMBRE_TABLA . " where " . self::EMAIL . " = ?";
			$sentencia = $pdo->prepare($comando);
			$sentencia->bindValue(1, $email, PDO::PARAM_STR);
			$resultado = $sentencia->execute();
			$array = array();
		while ($row = $sentencia->fetch(PDO::FETCH_ASSOC)){
			array_push($array, $row);
		}
		return[
			[
				"estado" => 1,
				"mensaje" => $array
			]
		];
		}catch (PDOException $e){
			throw new ExcepcionApi(1, $e->getMessage());
		}
		switch ($resultado) 
        {
            case 0:
                http_response_code(200);
                break;
            case 1:
                throw new ExcepcionApi(1, "Ha ocurrido un error.");
                break;
            default:
                throw new ExcepcionApi(ESTADO_FALLA_DESCONOCIDA, "Fallo desconocido.", 400);
        }
	}
	public function borrarUsuarioGrupo($usuario, $grupovacio){
		try{
			$pdo = ConexionBD::obtenerInstancia()->obtenerBD();
			
			$comando = "UPDATE " . self::NOMBRE_TABLA . " set " . self::ID_GRUPO . " = ? where " . self::EMAIL . " = ?";
			$sentencia = $pdo->prepare($comando);
			$sentencia->bindValue(1, $grupovacio, PDO::PARAM_STR);
			$sentencia->bindValue(2, $usuario->getEmail(), PDO::PARAM_STR);
			$resultado = $sentencia->execute();
			$array = array();
		while ($row = $sentencia->fetch(PDO::FETCH_ASSOC)){
			array_push($array, $row);
		}
		return[
			[
				"estado" => 1,
				"mensaje" => $array
			]
		];
		}catch (PDOException $e){
			throw new ExcepcionApi(1, $e->getMessage());
		}
		switch ($resultado) 
        {
            case 0:
                http_response_code(200);
                break;
            case 1:
                throw new ExcepcionApi(1, "Ha ocurrido un error.");
                break;
            default:
                throw new ExcepcionApi(ESTADO_FALLA_DESCONOCIDA, "Fallo desconocido.", 400);
        }
	}

	public function obtenerUsuarioMail($usuario){
		try{
			$pdo = ConexionBD::obtenerInstancia()->obtenerBD();

			$comando = "SELECT * FROM ". self::NOMBRE_TABLA . " WHERE " . self::EMAIL . " = ? ";
			$sentencia = $pdo->prepare($comando);
			$sentencia->bindValue(1, $usuario->getEmail(), PDO::PARAM_STR);
			$resultado = $sentencia->execute();
		$array = array();
		while ($row = $sentencia->fetch(PDO::FETCH_ASSOC)){
			array_push($array, $row);
		}
		return[
			[
				"estado" => 1,
				"mensaje" => $array
			]
		];
	}catch (PDOException $e){
		throw new ExcepcionApi(ESTADO_ERROR_BD, $e->getMessage());
	}
	switch ($resultado) 
        {
            case 0:
                http_response_code(200);
                break;
            case 1:
                throw new ExcepcionApi(1, "Ha ocurrido un error.");
                break;
            default:
                throw new ExcepcionApi(ESTADO_FALLA_DESCONOCIDA, "Fallo desconocido.", 400);
        }
	}
	public function verificarExistenciaEmailUsuario($correo){
		try{
			$pdo = ConexionBD::obtenerInstancia()->obtenerBD();

			$comando = "SELECT * FROM ". self::NOMBRE_TABLA . " WHERE " . self::EMAIL . " = ? ";
			$sentencia = $pdo->prepare($comando);
			$sentencia->bindValue(1, $correo, PDO::PARAM_STR);
			$resultado = $sentencia->execute();
		$array = array();
		while ($row = $sentencia->fetch(PDO::FETCH_ASSOC)){
			array_push($array, $row);
		}
		return[
			[
				"estado" => 1,
				"mensaje" => $array
			]
		];
	}catch (PDOException $e){
		throw new ExcepcionApi(ESTADO_ERROR_BD, $e->getMessage());
	}
	switch ($resultado) 
        {
            case 0:
                http_response_code(200);
                break;
            case 1:
                throw new ExcepcionApi(1, "Ha ocurrido un error.");
                break;
            default:
                throw new ExcepcionApi(ESTADO_FALLA_DESCONOCIDA, "Fallo desconocido.", 400);
        }
	}
	public function verificarExistenciaDNI($dni){
		try{
			$pdo = ConexionBD::obtenerInstancia()->obtenerBD();

			$comando = "SELECT * FROM ". self::NOMBRE_TABLA . " WHERE " . self::DNI . " = ? ";
			$sentencia = $pdo->prepare($comando);
			$sentencia->bindValue(1, $dni, PDO::PARAM_STR);
			$resultado = $sentencia->execute();
		$array = array();
		while ($row = $sentencia->fetch(PDO::FETCH_ASSOC)){
			array_push($array, $row);
		}
		return[
			[
				"estado" => 1,
				"mensaje" => $array
			]
		];
	}catch (PDOException $e){
		throw new ExcepcionApi(ESTADO_ERROR_BD, $e->getMessage());
	}
	switch ($resultado) 
        {
            case 0:
                http_response_code(200);
                break;
            case 1:
                throw new ExcepcionApi(1, "Ha ocurrido un error.");
                break;
            default:
                throw new ExcepcionApi(ESTADO_FALLA_DESCONOCIDA, "Fallo desconocido.", 400);
        }
	}
	public function obtenerUsuarioPorID($id){
		try{
			$pdo = ConexionBD::obtenerInstancia()->obtenerBD();

			$comando = "SELECT * FROM ". self::NOMBRE_TABLA . " WHERE id = ? ";
			$sentencia = $pdo->prepare($comando);
			$sentencia->bindValue(1, $id, PDO::PARAM_STR);
			$resultado = $sentencia->execute();
		$array = array();
		while ($row = $sentencia->fetch(PDO::FETCH_ASSOC)){
			array_push($array, $row);
		}
		return[
			[
				"estado" => 1,
				"mensaje" => $array
			]
		];
	}catch (PDOException $e){
		throw new ExcepcionApi(ESTADO_ERROR_BD, $e->getMessage());
	}
	switch ($resultado) 
        {
            case 0:
                http_response_code(200);
                break;
            case 1:
                throw new ExcepcionApi(1, "Ha ocurrido un error.");
                break;
            default:
                throw new ExcepcionApi(ESTADO_FALLA_DESCONOCIDA, "Fallo desconocido.", 400);
        }
	}

	public function obtenerIdUsuarioPorEmail($usuario){
		try{
			$pdo = ConexionBD::obtenerInstancia()->obtenerBD();

			$comando = "SELECT ID FROM ". self::NOMBRE_TABLA . " WHERE " . self::EMAIL . " = ? ";
			$sentencia = $pdo->prepare($comando);
			$sentencia->bindValue(1, $usuario->getEmail(), PDO::PARAM_STR);
			$resultado = $sentencia->execute();
		$array = array();
		while ($row = $sentencia->fetch(PDO::FETCH_ASSOC)){
			array_push($array, $row);
		}
		return[
			[
				"estado" => 1,
				"mensaje" => $array
			]
		];
	}catch (PDOException $e){
		throw new ExcepcionApi(ESTADO_ERROR_BD, $e->getMessage());
	}
	switch ($resultado) 
        {
            case 0:
                http_response_code(200);
                break;
            case 1:
                throw new ExcepcionApi(1, "Ha ocurrido un error.");
                break;
            default:
                throw new ExcepcionApi(ESTADO_FALLA_DESCONOCIDA, "Fallo desconocido.", 400);
        }
	}
	
		public function obtenerUsuariosGrupo($id){
		try{
			$pdo = ConexionBD::obtenerInstancia()->obtenerBD();

			$comando = "SELECT * FROM ". self::NOMBRE_TABLA . " WHERE " . self::ID_GRUPO . " = ? ";
			$sentencia = $pdo->prepare($comando);
			$sentencia->bindValue(1, $id, PDO::PARAM_STR);
			$resultado = $sentencia->execute();
		$array = array();
		while ($row = $sentencia->fetch(PDO::FETCH_ASSOC)){
			array_push($array, $row);
		}
		return[
			[
				"estado" => 1,
				"mensaje" => $array
			]
		];
	}catch (PDOException $e){
		throw new ExcepcionApi(ESTADO_ERROR_BD, $e->getMessage());
	}
	switch ($resultado) 
        {
            case 0:
                http_response_code(200);
                break;
            case 1:
                throw new ExcepcionApi(1, "Ha ocurrido un error.");
                break;
            default:
                throw new ExcepcionApi(ESTADO_FALLA_DESCONOCIDA, "Fallo desconocido.", 400);
        }
	}

}
/*public function obtenerTodosUsuariosMRegis($usuario){
		try{
		$pdo = ConexionBD::obtenerInstancia()->obtenerBD();
		$comando = "Select ". self::NOMBRE . " from " . self::NOMBRE_TABLA . " where " . self::NOMBRE . " != ?";
		$sentencia = $pdo->prepare($comando);
		$sentencia->bindValue(1, $usuario->getUsuario(), PDO::PARAM_STR);
		$resultado = $sentencia->execute();
		$array = array();
		while ($row = $sentencia->fetch(PDO::FETCH_ASSOC)){
			array_push($array, $row);
		}
		return[
			[
				"estado" => 1,
				"mensaje" => $array
			]
		];
	}catch (PDOException $e){
		throw new ExcepcionApi(ESTADO_ERROR_BD, $e->getMessage());
	}
	switch ($resultado) 
        {
            case 0:
                http_response_code(200);
                break;
            case 1:
                throw new ExcepcionApi(1, "Ha ocurrido un error.");
                break;
            default:
                throw new ExcepcionApi(ESTADO_FALLA_DESCONOCIDA, "Fallo desconocido.", 400);
        }
	}*/