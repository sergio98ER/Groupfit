<?php

require_once('datos/ConexionBD.php');
require_once('utilidades/ExcepcionApi.php');
require_once('datos/mensajes.php');

class ControladorEntrenador{
		// $nombre, $apellidos, $imagen, $token, $email, $contrasena, $telefono, $descripcion, $id_grupo;
	const NOMBRE_TABLA = "entrenador";
	const ID = "id";
	const NOMBRE = "nombre";
	const APELLIDOS = "apellidos";
	const IMAGEN = "imagen";
	const TOKEN = "token";
	const EMAIL = "email";
	const CONTRASENA = "contrasena";
	const TELEFONO = "telefono";
	const DESCRIPCION = "descripcion";
	
	public function obtenerTokenEntrenadorPorID($id){
		try{
			$pdo = ConexionBD::obtenerInstancia()->obtenerBD();

			$comando = "SELECT TOKEN FROM ". self::NOMBRE_TABLA . " WHERE " . self::ID . " = ? ";
			$sentencia = $pdo->prepare($comando);
			$sentencia->bindValue(1, $id, PDO::PARAM_STR);
			$resultado = $sentencia->execute();
		$array = array();
		while ($row = $sentencia->fetch(PDO::FETCH_ASSOC)){
			array_push($array, $row);
		}
		return[
			[
				"estado" => 1,
				"mensaje" => $array
			]
		];
	}catch (PDOException $e){
		throw new ExcepcionApi(ESTADO_ERROR_BD, $e->getMessage());
	}
	switch ($resultado) 
        {
            case 0:
                http_response_code(200);
                break;
            case 1:
                throw new ExcepcionApi(1, "Ha ocurrido un error.");
                break;
            default:
                throw new ExcepcionApi(ESTADO_FALLA_DESCONOCIDA, "Fallo desconocido.", 400);
        }
	}
	public function modificarTokenEntrenador($email_entrenador, $token_entrenador){
		try{
			$pdo = ConexionBD::obtenerInstancia()->obtenerBD();
			//$comando = "UPDATE ". self::NOMBRE_TABLA . " SET " . self::NOMBRE . " = ? ," . self::APELLIDOS . " = ? ,". self::TOKEN . "= ?,". self::EMAIL . " = ? ,". self::TELEFONO . " = ? ," . self::CONTRASENA . " = ?,". self::DESCRIPCION . " = ?  WHERE ". self::ID . " = 1";

			$comando = "UPDATE ". self::NOMBRE_TABLA . " SET " . self::TOKEN . " = ?  WHERE " . self::EMAIL . " = ? ";
			
			$sentencia = $pdo->prepare($comando);
			$sentencia->bindValue(1, $token_entrenador, PDO::PARAM_STR);
			$sentencia->bindValue(2, $email_entrenador, PDO::PARAM_STR);
			$resultado = $sentencia->execute();
		$array = array();
		while ($row = $sentencia->fetch(PDO::FETCH_ASSOC)){
			array_push($array, $row);
		}
		return[
			[
				"estado" => 1,
				"mensaje" => $array
			]
		];
	}catch (PDOException $e){
		
	}
	switch ($resultado) 
        {
            case 0:
                http_response_code(200);
                break;
            case 1:
                throw new ExcepcionApi(1, "Ha ocurrido un error.");
                break;
            default:
                throw new ExcepcionApi(ESTADO_FALLA_DESCONOCIDA, "Fallo desconocido.", 400);
        }
	}
	public function obtenerEntrenadorPorID($id){
		try{
			$pdo = ConexionBD::obtenerInstancia()->obtenerBD();

			$comando = "SELECT * FROM ". self::NOMBRE_TABLA . " WHERE " . self::ID . " = ? ";
			$sentencia = $pdo->prepare($comando);
			$sentencia->bindValue(1, $id, PDO::PARAM_STR);
			$resultado = $sentencia->execute();
		$array = array();
		while ($row = $sentencia->fetch(PDO::FETCH_ASSOC)){
			array_push($array, $row);
		}
		return[
			[
				"estado" => 1,
				"mensaje" => $array
			]
		];
	}catch (PDOException $e){
		throw new ExcepcionApi(ESTADO_ERROR_BD, $e->getMessage());
	}
	switch ($resultado) 
        {
            case 0:
                http_response_code(200);
                break;
            case 1:
                throw new ExcepcionApi(1, "Ha ocurrido un error.");
                break;
            default:
                throw new ExcepcionApi(ESTADO_FALLA_DESCONOCIDA, "Fallo desconocido.", 400);
        }
	}
	
	public function obtenerEntrenadorMail($entrenador){
		try{
			$pdo = ConexionBD::obtenerInstancia()->obtenerBD();

			$comando = "SELECT * FROM ". self::NOMBRE_TABLA . " WHERE " . self::EMAIL . " = ? ";
			$sentencia = $pdo->prepare($comando);
			$sentencia->bindValue(1, $entrenador->getEmail(), PDO::PARAM_STR);
			$resultado = $sentencia->execute();
		$array = array();
		while ($row = $sentencia->fetch(PDO::FETCH_ASSOC)){
			array_push($array, $row);
		}
		return[
			[
				"estado" => 1,
				"mensaje" => $array
			]
		];
	}catch (PDOException $e){
		throw new ExcepcionApi(ESTADO_ERROR_BD, $e->getMessage());
	}
	switch ($resultado) 
        {
            case 0:
                http_response_code(200);
                break;
            case 1:
                throw new ExcepcionApi(1, "Ha ocurrido un error.");
                break;
            default:
                throw new ExcepcionApi(ESTADO_FALLA_DESCONOCIDA, "Fallo desconocido.", 400);
        }
	}
	
	public function obtenerEntrenador($entrenador){
		try{
			$pdo = ConexionBD::obtenerInstancia()->obtenerBD();

			$comando = "SELECT * FROM ". self::NOMBRE_TABLA . " WHERE " . self::EMAIL . " = ? and " . self::CONTRASENA . " = ?";
			$sentencia = $pdo->prepare($comando);
			$sentencia->bindValue(1, $entrenador->getEmail(), PDO::PARAM_STR);
			$sentencia->bindValue(2, $entrenador->getContrasena(), PDO::PARAM_STR);
			$resultado = $sentencia->execute();
		$array = array();
		while ($row = $sentencia->fetch(PDO::FETCH_ASSOC)){
			array_push($array, $row);
		}
		return[
			[
				"estado" => 1,
				"mensaje" => $array
			]
		];
	}catch (PDOException $e){
		throw new ExcepcionApi(ESTADO_ERROR_BD, $e->getMessage());
	}
	switch ($resultado) 
        {
            case 0:
                http_response_code(200);
                break;
            case 1:
                throw new ExcepcionApi(1, "Ha ocurrido un error.");
                break;
            default:
                throw new ExcepcionApi(ESTADO_FALLA_DESCONOCIDA, "Fallo desconocido.", 400);
        }
	}
	public function modificarEntrenador($entrenador){
		try{
			$pdo = ConexionBD::obtenerInstancia()->obtenerBD();
			//nombre, apellidos, token, email, telefono, contrasena, descripcion;
			$comando = "UPDATE ". self::NOMBRE_TABLA . " SET " . self::NOMBRE . " = ? ," . self::APELLIDOS . " = ? ,". self::TOKEN . "= ?,". self::EMAIL . " = ? ,". self::TELEFONO . " = ? ," . self::CONTRASENA . " = ?,". self::DESCRIPCION . " = ?  WHERE ". self::ID . " = 1";
			$sentencia = $pdo->prepare($comando);
			$sentencia->bindValue(1, $entrenador->getNombre(), PDO::PARAM_STR);
			$sentencia->bindValue(2, $entrenador->getApellidos(), PDO::PARAM_STR);
			$sentencia->bindValue(3, $entrenador->getToken(), PDO::PARAM_STR);
			$sentencia->bindValue(4, $entrenador->getEmail(), PDO::PARAM_STR);
			$sentencia->bindValue(5, $entrenador->getTelefono(), PDO::PARAM_STR);
			$sentencia->bindValue(6, $entrenador->getContrasena(), PDO::PARAM_STR);
			$sentencia->bindValue(7, $entrenador->getDescripcion(), PDO::PARAM_STR);
			$resultado = $sentencia->execute();
		$array = array();
		while ($row = $sentencia->fetch(PDO::FETCH_ASSOC)){
			array_push($array, $row);
		}
		return[
			[
				"estado" => 1,
				"mensaje" => $array
			]
		];
	}catch (PDOException $e){
		throw new ExcepcionApi(ESTADO_ERROR_BD, $e->getMessage());
	}
	switch ($resultado){
            case 0:
                http_response_code(200);
                break;
            case 1:
                throw new ExcepcionApi(1, "Ha ocurrido un error.");
                break;
            default:
                throw new ExcepcionApi(ESTADO_FALLA_DESCONOCIDA, "Fallo desconocido.", 400);
        }
	}
	
}
/*public function obtenerTodosUsuariosMRegis($usuario){
		try{
		$pdo = ConexionBD::obtenerInstancia()->obtenerBD();
		$comando = "Select ". self::NOMBRE . " from " . self::NOMBRE_TABLA . " where " . self::NOMBRE . " != ?";
		$sentencia = $pdo->prepare($comando);
		$sentencia->bindValue(1, $usuario->getUsuario(), PDO::PARAM_STR);
		$resultado = $sentencia->execute();
		$array = array();
		while ($row = $sentencia->fetch(PDO::FETCH_ASSOC)){
			array_push($array, $row);
		}
		return[
			[
				"estado" => 1,
				"mensaje" => $array
			]
		];
	}catch (PDOException $e){
		throw new ExcepcionApi(ESTADO_ERROR_BD, $e->getMessage());
	}
	switch ($resultado) 
        {
            case 0:
                http_response_code(200);
                break;
            case 1:
                throw new ExcepcionApi(1, "Ha ocurrido un error.");
                break;
            default:
                throw new ExcepcionApi(ESTADO_FALLA_DESCONOCIDA, "Fallo desconocido.", 400);
        }
	}*/