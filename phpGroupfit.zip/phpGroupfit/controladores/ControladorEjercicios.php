<?php

require_once('datos/ConexionBD.php');
require_once('utilidades/ExcepcionApi.php');
require_once('datos/mensajes.php');

class ControladorEjercicios{
		
	const NOMBRE_TABLA = "ejercicio";
	const RUTINA = "rutina";
	const MUSCULO = "musculo";
	const NOMBRE_EJERCICIO = "nombre_ejercicio";
	const SERIES_EJERCICIO = "series_ejercicio";
	const REPETICIONES_EJERCICIO = "repeticion_ejercicio";
	const PESO_INICIO = "peso_inicio";
	const PESO_FIN = "peso_fin";
	
	public function eliminarEjerciciosRutina($rutina){
		try{
			$pdo = ConexionBD::obtenerInstancia()->obtenerBD();
			
			$comando = "DELETE FROM " . self::NOMBRE_TABLA . " where ". self::RUTINA . " = ?";
			$sentencia = $pdo->prepare($comando);
			$sentencia->bindValue(1, $rutina, PDO::PARAM_STR);
			$resultado = $sentencia->execute();
			$array = array();
		while ($row = $sentencia->fetch(PDO::FETCH_ASSOC)){
			array_push($array, $row);
		}
		return[
			[
				"estado" => 1,
				"mensaje" => $array
			]
		];
		}catch (PDOException $e){
			throw new ExcepcionApi(1, $e->getMessage());
		}
		switch ($resultado) 
        {
            case 0:
                http_response_code(200);
                break;
            case 1:
                throw new ExcepcionApi(1, "Ha ocurrido un error.");
                break;
            default:
                throw new ExcepcionApi(ESTADO_FALLA_DESCONOCIDA, "Fallo desconocido.", 400);
        }
	}
	public function modificarPesosEjercicio($peso_inicio, $peso_fin, $id, $nombre_ejercicio){
		try{
			$pdo = ConexionBD::obtenerInstancia()->obtenerBD();
			//nombre, apellidos, token, email, telefono, contrasena, descripcion;
			$comando = "UPDATE " . self::NOMBRE_TABLA . " SET " . SELF::PESO_INICIO . " = ? ," . SELF::PESO_FIN . " = ? WHERE " . self::RUTINA . " = ? and " . self::NOMBRE_EJERCICIO . " = ?";
			$sentencia = $pdo->prepare($comando);
			$sentencia->bindValue(1, $peso_inicio, PDO::PARAM_STR);
			$sentencia->bindValue(2, $peso_fin, PDO::PARAM_STR);
			$sentencia->bindValue(3, $id, PDO::PARAM_STR);
			$sentencia->bindValue(4, $nombre_ejercicio, PDO::PARAM_STR);
			
			
			$resultado = $sentencia->execute();
			$array = array();
		while ($row = $sentencia->fetch(PDO::FETCH_ASSOC)){
			array_push($array, $row);
		}
		return[
			[
				"estado" => 1,
				"mensaje" => $array
			]
		];
	}catch (PDOException $e){
		throw new ExcepcionApi(1, $e->getMessage());
	}
	switch ($resultado){
            case 0:
                http_response_code(200);
                break;
            case 1:
                throw new ExcepcionApi(1, "Ha ocurrido un error.");
                break;
            default:
                throw new ExcepcionApi(ESTADO_FALLA_DESCONOCIDA, "Fallo desconocido.", 400);
        }
	}
	
	public function obtenerEjerciciosRutina($id_rutina){
		try{
			$pdo = ConexionBD::obtenerInstancia()->obtenerBD();

			$comando = "SELECT * FROM ". self::NOMBRE_TABLA . " WHERE " . self::RUTINA . " = ? ";
			$sentencia = $pdo->prepare($comando);
			$sentencia->bindValue(1, $id_rutina, PDO::PARAM_STR);
			$resultado = $sentencia->execute();
		$array = array();
		while ($row = $sentencia->fetch(PDO::FETCH_ASSOC)){
			array_push($array, $row);
		}
		return[
			[
				"estado" => 1,
				"mensaje" => $array
			]
		];
	}catch (PDOException $e){
		throw new ExcepcionApi(ESTADO_ERROR_BD, $e->getMessage());
	}
	switch ($resultado) 
        {
            case 0:
                http_response_code(200);
                break;
            case 1:
                throw new ExcepcionApi(1, "Ha ocurrido un error.");
                break;
            default:
                throw new ExcepcionApi(ESTADO_FALLA_DESCONOCIDA, "Fallo desconocido.", 400);
        }
	}
	
	public function modificarEjercicio($EJERCICIO, $id){
		try{
			$pdo = ConexionBD::obtenerInstancia()->obtenerBD();
			//nombre, apellidos, token, email, telefono, contrasena, descripcion;
			$comando = "UPDATE " . self::NOMBRE_TABLA . " SET " . self::RUTINA . " = ? , " . self::MUSCULO . " = ? ," . self::NOMBRE_EJERCICIO . " = ? ," . self::SERIES_EJERCICIO . " = ? ," . self::REPETICIONES_EJERCICIO . " = ? ," . SELF::PESO_INICIO . " = ? ," . SELF::PESO_FIN . " = ? WHERE " . self::RUTINA . " = ?";
			$sentencia = $pdo->prepare($comando);
			$sentencia->bindValue(1, $EJERCICIO->getRutina(), PDO::PARAM_STR);
			$sentencia->bindValue(2, $EJERCICIO->getMusculo(), PDO::PARAM_STR);
			$sentencia->bindValue(3, $EJERCICIO->getNombre_ejercicio(), PDO::PARAM_STR);
			$sentencia->bindValue(4, $EJERCICIO->getSeries_ejercicio(), PDO::PARAM_STR);
			$sentencia->bindValue(5, $EJERCICIO->getRepeticiones_ejercicio(), PDO::PARAM_STR);
			$sentencia->bindValue(6, $EJERCICIO->getPeso_inicio(), PDO::PARAM_STR);
			$sentencia->bindValue(7, $EJERCICIO->getPeso_fin(), PDO::PARAM_STR);
			$sentencia->bindValue(8, $id, PDO::PARAM_STR);
			
			$resultado = $sentencia->execute();
			$array = array();
		while ($row = $sentencia->fetch(PDO::FETCH_ASSOC)){
			array_push($array, $row);
		}
		return[
			[
				"estado" => 1,
				"mensaje" => $array
			]
		];
	}catch (PDOException $e){
		throw new ExcepcionApi(1, $e->getMessage());
	}
	switch ($resultado){
            case 0:
                http_response_code(200);
                break;
            case 1:
                throw new ExcepcionApi(1, "Ha ocurrido un error.");
                break;
            default:
                throw new ExcepcionApi(ESTADO_FALLA_DESCONOCIDA, "Fallo desconocido.", 400);
        }
	}
	
	public function insertarEjercicio($ejercicio){
		try{
			$pdo = ConexionBD::obtenerInstancia()->obtenerBD();
			$comando = "INSERT INTO " . self::NOMBRE_TABLA . "( " . self::RUTINA . "," . self::MUSCULO . "," . self::NOMBRE_EJERCICIO . "," . self::SERIES_EJERCICIO . "," . self::REPETICIONES_EJERCICIO . "," . self::PESO_INICIO . "," . self::PESO_FIN . ") VALUES(?,?,?,?,?,?,?)";
			$sentencia = $pdo->prepare($comando);
			$sentencia->bindValue(1, $ejercicio->getRutina(), PDO::PARAM_STR);
			$sentencia->bindValue(2, $ejercicio->getMusculo(), PDO::PARAM_STR);
			$sentencia->bindValue(3, $ejercicio->getNombre_ejercicio(), PDO::PARAM_STR);
			$sentencia->bindValue(4, $ejercicio->getSeries_ejercicio(), PDO::PARAM_STR);
			$sentencia->bindValue(5, $ejercicio->getRepeticiones_ejercicio(), PDO::PARAM_STR);
			$sentencia->bindValue(6, $ejercicio->getPeso_inicio(), PDO::PARAM_STR);
			$sentencia->bindValue(7, $ejercicio->getPeso_fin(), PDO::PARAM_STR);
			
			
		
			$resultado = $sentencia->execute();
		}catch (PDOException $e){
			throw new ExcepcionApi(1, $e->getMessage());
		}
		switch ($resultado) 
        {
            case 0:
                http_response_code(200);
                break;
            case 1:
                throw new ExcepcionApi(1, "Ha ocurrido un error.");
                break;
            default:
                throw new ExcepcionApi(ESTADO_FALLA_DESCONOCIDA, "Fallo desconocido.", 400);
        }
	}
	
		public function eliminarEjercicio($rutina, $nombre_ejercicio){
		try{
			$pdo = ConexionBD::obtenerInstancia()->obtenerBD();
			
			$comando = "DELETE FROM " . self::NOMBRE_TABLA . " where " . self::NOMBRE_EJERCICIO . " = ? and " . self::RUTINA . " = ?";
			$sentencia = $pdo->prepare($comando);
			$sentencia->bindValue(1, $nombre_ejercicio, PDO::PARAM_STR);
			$sentencia->bindValue(2, $rutina, PDO::PARAM_STR);
			$resultado = $sentencia->execute();
			$array = array();
		while ($row = $sentencia->fetch(PDO::FETCH_ASSOC)){
			array_push($array, $row);
		}
		return[
			[
				"estado" => 1,
				"mensaje" => $array
			]
		];
		}catch (PDOException $e){
			throw new ExcepcionApi(1, $e->getMessage());
		}
		switch ($resultado) 
        {
            case 0:
                http_response_code(200);
                break;
            case 1:
                throw new ExcepcionApi(1, "Ha ocurrido un error.");
                break;
            default:
                throw new ExcepcionApi(ESTADO_FALLA_DESCONOCIDA, "Fallo desconocido.", 400);
        }
	}
}
