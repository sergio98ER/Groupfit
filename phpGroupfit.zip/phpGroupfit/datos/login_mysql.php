<?php

define("NOMBRE_HOST", "localhost");
define("BASE_DE_DATOS", "Groupfit");
define("USUARIO", "root");
define("CONTRASENA", "");