<?php

	ini_set('display_erros', 1);
	require_once('vistas/VistaJson.php');
	require_once('controladores/ControladorEntrenador.php');
	require_once('modelos/Entrenador.php');

	$vista = new VistaJson();

	set_exception_handler(function ($exception) use ($vista){
		$cuerpo = array(
			array(
				"estado" => $exception->estado,
				"mensaje" => $exception->getMessage()
			)
		);
		if ($exception->getCode()){
			$vista->estado = $exception->getCode();
		}else{
			$vista->estado = 500;
		}
		$vista->imprimir($cuerpo);
	}
	);
	
	$nombre = $_REQUEST['nombre'];
	$apellidos = $_REQUEST['apellidos'];
	$token = $_REQUEST['token'];
	$email = $_REQUEST['email'];
	$contrasena = $_REQUEST['contrasena'];
	$telefono = $_REQUEST['telefono'];
	$descripcion = $_REQUEST['descripcion'];
	// $nombre, $apellidos, $imagen, $token, $email, $contrasena, $telefono, $descripcion, $id_grupo;
	$entrenador = new Entrenador($nombre, $apellidos, "", $token, $email, $contrasena, $telefono, $descripcion);
	$controladoren = new ControladorEntrenador();
	$vista->imprimir($controladoren->modificarEntrenador($entrenador));