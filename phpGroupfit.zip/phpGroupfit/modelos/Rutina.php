<?php

class Rutina{
	
	private $nombre, $descripcion;
	
	public function __construct($nnombre, $ndescripcion){
		$this->nombre = $nnombre;
		$this->descripcion = $ndescripcion;
	}
	
	function setNombre($nombre) { $this->nombre = $nombre; }
	function getNombre() { return $this->nombre; }

	function setDescripcion($descripcion) { $this->descripcion = $descripcion; }
	function getDescripcion() { return $this->descripcion; }


	public function toString(){
		return[
			"nombre" => utf8_encode($this->nombre),
			"descripcion" => utf8_encode($this->descripcion),
	
		];
	}
}