<?php

class Mensaje{

	private $titulo, $mensaje;
	
	public function __construct($ntitulo, $nmensaje){
		$this->titulo = $ntitulo;
		$this->mensaje = $nmensaje;
	}
	public function getTitulo(){
		return $this->titulo;
	}
	public function getMensaje(){
		return $this->mensaje;
	}
	public function toString(){
		return[
			"titulo" => utf8_encode($this->titulo),
			"mensaje" => utf8_encode($this->mensaje)
		];
	}
}