<?php

class Usuario{
	private $nombre, $apellidos, $email, $contrasena, $dni, $peso, $altura, $pressBanca, $dominadas, $forma_actual, $token, $tiempo_1km, $id_grupo, $imagen, $id_entreno;
	
	public function __construct($nnombre, $napellidos, $nemail, $ncontrasena, $ndni, $npeso, $naltura, $npressBanca, $ndominadas, $nforma_actual, $ntoken, $ntiempo_1km, $nid_grupo, $nimagen, $nid_entreno){
		$this->nombre = $nnombre;
		$this->apellidos = $napellidos;
		$this->email = $nemail;
		$this->contrasena = $ncontrasena;
		$this->dni = $ndni;
		$this->peso = $npeso;
		$this->altura = $naltura;
		$this->pressBanca = $npressBanca;
		$this->dominadas = $ndominadas;
		$this->forma_actual = $nforma_actual;
		$this->token = $ntoken;
		$this->tiempo_1km = $ntiempo_1km;
		$this->id_grupo = $nid_grupo;
		$this->imagen = $nimagen;
		$this->id_entreno = $nid_entreno;
		
	}
	
	function setNombre($nombre) { $this->nombre = $nombre; }
	function getNombre() { return $this->nombre; }

	function setApellidos($apellidos) { $this->apellidos = $apellidos; }
	function getApellidos() { return $this->apellidos; }

	function setEmail($email) { $this->email = $email; }
	function getEmail() { return $this->email; }

	function setContrasena($contrasena) { $this->contrasena = $contrasena; }
	function getContrasena() { return $this->contrasena; }

	function setDni($dni) { $this->dni = $dni; }
	function getDni() { return $this->dni; }

	function setPeso($peso) { $this->peso = $peso; }
	function getPeso() { return $this->peso; }

	function setAltura($altura) { $this->altura = $altura; }
	function getAltura() { return $this->altura; }

	function setPressBanca($pressBanca) { $this->pressBanca = $pressBanca; }
	function getPressBanca() { return $this->pressBanca; }

	function setDominadas($dominadas) { $this->dominadas = $dominadas; }
	function getDominadas() { return $this->dominadas; }

	function setForma_actual($forma_actual) { $this->forma_actual = $forma_actual; }
	function getForma_actual() { return $this->forma_actual; }

	function setToken($token) { $this->token = $token; }
	function getToken() { return $this->token; }

	function setTiempo_1km($tiempo_1km) { $this->tiempo_1km = $tiempo_1km; }
	function getTiempo_1km() { return $this->tiempo_1km; }

	function setId_grupo($id_grupo) { $this->id_grupo = $id_grupo; }
	function getId_grupo() { return $this->id_grupo; }

	function setImagen($imagen) { $this->imagen = $imagen; }
	function getImagen() { return $this->imagen; }

	function setId_entreno($id_entreno) { $this->id_entreno = $id_entreno; }
	function getId_entreno() { return $this->id_entreno; }

	public function toString(){
		return[
			"nombre" => utf8_encode($this->nombre),
			"apellidos" => utf8_encode($this->apellidos),
			"email" => utf8_encode($this->email),
			"contrasena" => utf8_encode($this->contrasena),
			"dni" => utf8_encode($this->dni),
			"peso" => utf8_encode($this->peso),
			"altura" => utf8_encode($this->altura),
			"pressBanca" => utf8_encode($this->pressBanca),
			"dominadas" => utf8_encode($this->dominadas),
			"forma_actual" => utf8_encode($this->forma_actual),
			"token" => utf8_encode($this->token),
			"tiempo_1km" => utf8_encode($this->tiempo_1km),
			"id_grupo" => utf8_encode($this->id_grupo),
			"imagen" => utf8_encode($this->imagen),
			"id_entreno" => utf8_encode($this->id_entreno)
		];
	}
}