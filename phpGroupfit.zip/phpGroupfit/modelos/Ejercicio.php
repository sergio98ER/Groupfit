<?php

class Ejercicio{
	
	private $rutina;
	private $musculo;
	private $nombre_ejercicio;
	private $series_ejercicio;
	private $repeticiones_ejercicio;
	private $peso_inicio;
	private $peso_fin;
	
	public function __construct($nrutina, $nmusculo, $nnombre_ejercicio, $nseries_ejercicio, $nrepeticiones_ejercicio, $npeso_inicio, $npeso_fin){
		$this->rutina = $nrutina;
		$this->musculo = $nmusculo;
		$this->nombre_ejercicio = $nnombre_ejercicio;
		$this->series_ejercicio = $nseries_ejercicio;
		$this->repeticiones_ejercicio = $nrepeticiones_ejercicio;
		$this->peso_inicio = $npeso_inicio;
		$this->peso_fin = $npeso_fin;
	}
	function setRutina($rutina) { $this->rutina = $rutina; }
	function getRutina() { return $this->rutina; }
	
	function setMusculo($musculo) { $this->musculo = $musculo; }
	function getMusculo() { return $this->musculo; }
	
	function setNombre_ejercicio($nombre_ejercicio) { $this->nombre_ejercicio = $nombre_ejercicio; }
	function getNombre_ejercicio() { return $this->nombre_ejercicio; }
	
	function setSeries_ejercicio($series_ejercicio) { $this->series_ejercicio = $series_ejercicio; }
	function getSeries_ejercicio() { return $this->series_ejercicio; }
	
	function setRepeticiones_ejercicio($repeticiones_ejercicio_ejercicio) { $this->repeticiones_ejercicio = $repeticiones_ejercicio; }
	function getRepeticiones_ejercicio() { return $this->repeticiones_ejercicio; }
	
	function setPeso_inicio($peso_inicio) { $this->peso_inicio = $peso_inicio; }
	function getPeso_inicio() { return $this->peso_inicio; }
	
	function setPeso_fin($peso_fin) { $this->peso_fin = $peso_fin; }
	function getPeso_fin() { return $this->peso_fin; }
	
	public function toString(){
		return[
			"rutina" => utf8_encode($this->rutina),
			"musculo" => utf8_encode($this->musculo),
			"nombre_ejercicio" => utf8_encode($this->nombre_ejercicio),
			"series_ejercicio" => utf8_encode($this->series_ejercicio),
			"repeticion_ejercicio" => utf8_encode($this->repeticiones_ejercicio),
			"peso_inicio" => utf8_encode($this->peso_inicio),
			"peso_fin" => utf8_encode($this->peso_fin),
		
		];
	}

	}
