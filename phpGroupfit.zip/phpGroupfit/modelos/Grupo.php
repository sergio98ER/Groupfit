<?php

class Grupo{
	private $nombre, $objetivo, $id_entrenador;
	
	public function __construct($nnombre, $nobjetivo, $nid_entrenador){
		$this->nombre = $nnombre;
		$this->objetivo = $nobjetivo;
		$this->id_entrenador = $nid_entrenador;
	}
	
	function setNombre($nombre) { $this->nombre = $nombre; }
	function getNombre() { return $this->nombre; }

	function setObjetivo($objetivo) { $this->objetivo = $objetivo; }
	function getObjetivo() { return $this->objetivo; }


	function setId_entrenador($id_entrenador) { $this->id_entrenador = $id_entrenador; }
	function getId_entrenador() { return $this->id_entrenador; }

	public function toString(){
		return[
			"nombre" => utf8_encode($this->nombre),
			"objetivo" => utf8_encode($this->objetivo),
			"id_entrenador" => utf8_encode($this->id_entrenador)
		];
	}
}