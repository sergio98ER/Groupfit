<?php

class Entrenador{

	private $nombre, $apellidos, $imagen, $token, $email, $contrasena, $telefono, $descripcion;
	
	public function __construct($nnombre, $napellidos, $nimagen, $ntoken, $nemail, $ncontrasena, $ntelefono, $ndescripcion){
		$this->nombre = $nnombre;
		$this->apellidos = $napellidos;
		$this->imagen = $nimagen;
		$this->token = $ntoken;
		$this->email = $nemail;
		$this->contrasena = $ncontrasena;
		$this->telefono = $ntelefono;
		$this->descripcion = $ndescripcion;
	}
	
	function setNombre($nombre){ $this->nombre = $nombre; }
	function getNombre() { return $this->nombre; }

	function setApellidos($apellidos) { $this->apellidos = $apellidos; }
	function getApellidos() { return $this->apellidos; }

	function setImagen($imagen) { $this->imagen = $imagen; }
	function getImagen() { return $this->imagen; }

	function setToken($token) { $this->token = $token; }
	function getToken() { return $this->token; }

	function setEmail($email) { $this->email = $email; }
	function getEmail() { return $this->email; }

	function setContrasena($contrasena) { $this->contrasena = $contrasena; }
	function getContrasena() { return $this->contrasena; }

	function setTelefono($telefono) { $this->telefono = $telefono; }
	function getTelefono() { return $this->telefono; }

	function setDescripcion($descripcion) { $this->descripcion = $descripcion; }
	function getDescripcion() { return $this->descripcion; }
	
	public function toString(){
		return[
			"nombre" => utf8_encode($this->nombre),
			"apellidos" => utf8_encode($this->apellidos),
			"imagen" => utf8_encode($this->imagen),
			"token" => utf8_encode($this->token),
			"email" => utf8_encode($this->email),
			"contrasena" => utf8_encode($this->contrasena),
			"telefono" => utf8_encode($this->telefono),
			"descripcion" => utf8_encode($this->descripcion),
		];
	}
}