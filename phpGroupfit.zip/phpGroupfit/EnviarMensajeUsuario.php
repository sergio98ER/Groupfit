<?php
	ini_set('display_errors', 1);
	require_once('controladores/ControladorMensajes.php');
	require_once('utilidades/ExcepcionApi.php');
	require_once('modelos/Mensaje.php');
    require_once('vistas/VistaJson.php');
	
	const API_ACCESS_KEY = 'AAAA3fPry30:APA91bEcyrEpY_cGC2S74belreVh5IAfVmJrG_0IYs0jQ2RreqvL9xtkeHsmhT3zIlwcxtc0-rhCrFclDE6NYEWAL_aMswcHV08IhdVb7qSQ43xWSJXsA_c7N38HshV0voZQMv110N4T';
	
	$vista = new VistaJson();
	
    set_exception_handler(function ($exception) use ($vista){
	$cuerpo = array(
		array(
			"estado" => $exception->estado,
			"mensaje" => $exception->getMessage()
		)
	);
	if ($exception->getCode()){
		$vista->estado = $exception->getCode();
	}else{
		$vista->estado = 500;
	}
	$vista->imprimir($cuerpo);
}
);
	$emisor = $_REQUEST['emisor'];
	$titulomensaje = $_REQUEST['titulo'];
	$cuerpomensaje = $_REQUEST['mensaje'];
	$ControladorMensajes = new ControladorMensajes();
	$mensaje = new Mensaje($titulomensaje, $cuerpomensaje);
	$vista->imprimir($ControladorMensajes->enviarMensajeUsuario($emisor, $mensaje));
?>