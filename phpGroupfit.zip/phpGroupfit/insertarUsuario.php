<?php

require_once('vistas/VistaJson.php');
require_once('controladores/ControladorUsuarios.php');
require_once('modelos/Usuario.php');

$vista = new VistaJson();

set_exception_handler(function ($exception) use ($vista){
	$cuerpo = array(
		array(
			"estado" => $exception->estado,
			"mensaje" => $exception->getMessage()
		)
	);
	if ($exception->getCode()){
		$vista->estado = $exception->getCode();
	}else{
		$vista->estado = 500;
	}
	$vista->imprimir($cuerpo);
}
);
// $nombre, $apellidos, $email, $contrasena, $dni, $peso, $altura, $pressBanca, $dominadas, $forma_actual, $token, $tiempo_1km $id_grupo, $imagen, $id_entreno;
	$nombre = $_REQUEST['nombre'];
	$apellidos = $_REQUEST['apellidos'];
	$email = $_REQUEST['email'];
	$contrasena = $_REQUEST['contrasena'];
	$dni = $_REQUEST['dni'];
	$peso = $_REQUEST['peso'];
	$altura = $_REQUEST['altura'];
	$pressbanca = $_REQUEST['pressBanca'];
	$dominadas = $_REQUEST['dominadas'];
	$forma_actual = $_REQUEST['forma_actual'];
	$token = $_REQUEST['token'];
	$tiempo_1km = $_REQUEST['tiempo_1km'];
	$id_grupo = $_REQUEST['id_grupo'];
	$imagen = $_REQUEST['imagen'];
	$id_entreno = $_REQUEST['id_entreno'];
	
$usuario = new Usuario($nombre, $apellidos, $email, $contrasena, $dni, $peso, $altura, $pressbanca, $dominadas, $forma_actual, $token, $tiempo_1km, $id_grupo, $imagen, $id_entreno);

$controladoru = new ControladorUsuarios();

$vista->imprimir($controladoru->insertarUsuario($usuario));